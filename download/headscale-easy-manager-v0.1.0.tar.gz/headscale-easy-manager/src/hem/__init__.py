"""بسته hem — Headscale Easy Manager (نصب‌کننده و مدیر CLI برای Headscale)."""

__version__ = "0.1.0"
