"""راه‌اندازی pytest — افزودن src به مسیر ایمپورت."""

import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
